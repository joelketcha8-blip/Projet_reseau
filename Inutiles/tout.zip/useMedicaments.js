'use client';
// ordonnance-app/hooks/useMedicaments.js

import { useState, useEffect, useCallback } from 'react';
import { medicamentsAPI } from '@/lib/api';

export function useMedicaments(recherche = '', categorie = '') {
  const [medicaments, setMedicaments] = useState([]);
  const [loading, setLoading]         = useState(false);
  const [error, setError]             = useState(null);

  const fetch = useCallback(async () => {
    setLoading(true);
    try {
      const params = {};
      if (recherche) params.recherche = recherche;
      if (categorie) params.categorie = categorie;
      const data = await medicamentsAPI.lister(params);
      setMedicaments(data.data || []);
      // Cache local pour offline
      localStorage.setItem('ord_cache_medicaments', JSON.stringify(data.data || []));
    } catch {
      // Fallback cache
      const cached = localStorage.getItem('ord_cache_medicaments');
      if (cached) setMedicaments(JSON.parse(cached));
    } finally {
      setLoading(false);
    }
  }, [recherche, categorie]);

  useEffect(() => { fetch(); }, [fetch]);

  return { medicaments, loading, error, refetch: fetch };
}
