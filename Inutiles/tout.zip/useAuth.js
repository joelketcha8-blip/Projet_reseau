'use client';
// ordonnance-app/hooks/useAuth.js
// Hook pour gérer l'authentification dans les composants

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useApp } from '@/context/AppContext';

export function useAuth() {
  const { login, loginWith2FA, logout, user, isAuthenticated, addNotification } = useApp();
  const router = useRouter();

  const [loading, setLoading]                 = useState(false);
  const [error, setError]                     = useState(null);
  const [twoFactorRequired, setTwoFactorRequired] = useState(false);
  const [tempToken, setTempToken]             = useState(null);

  // ── Connexion principale ─────────────────────────────────────
  async function handleLogin(email, motDePasse) {
    setLoading(true);
    setError(null);
    try {
      const result = await login(email, motDePasse);

      if (result.twoFactorRequis) {
        setTwoFactorRequired(true);
        setTempToken(result.tokenTemporaire);
        setLoading(false);
        return;
      }

      addNotification('success', 'Connexion réussie', `Bienvenue ${result.user.prenom} !`);
      redirectByRole(result.user.role);
    } catch (err) {
      setError(err.message || 'Email ou mot de passe incorrect');
    } finally {
      setLoading(false);
    }
  }

  // ── Vérification du code 2FA ─────────────────────────────────
  async function handle2FA(code) {
    setLoading(true);
    setError(null);
    try {
      const result = await loginWith2FA(tempToken, code);
      addNotification('success', 'Connexion réussie', `Bienvenue ${result.user.prenom} !`);
      redirectByRole(result.user.role);
    } catch (err) {
      setError(err.message || 'Code 2FA incorrect');
    } finally {
      setLoading(false);
    }
  }

  // ── Déconnexion ──────────────────────────────────────────────
  function handleLogout() {
    logout();
    router.push('/login');
  }

  // ── Redirection selon le rôle ────────────────────────────────
  function redirectByRole(role) {
    const routes = {
      MEDECIN:    '/dashboard',
      PATIENT:    '/dashboard',
      PHARMACIEN: '/dashboard',
      ADMIN:      '/dashboard',
    };
    router.push(routes[role] || '/dashboard');
  }

  return {
    loading, error, setError,
    twoFactorRequired,
    handleLogin, handle2FA, handleLogout,
    user, isAuthenticated,
  };
}
