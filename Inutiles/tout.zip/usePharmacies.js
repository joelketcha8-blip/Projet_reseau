'use client';
// ordonnance-app/hooks/usePharmacies.js

import { useState, useCallback } from 'react';
import { pharmaciesAPI } from '@/lib/api';
import { patientsAPI } from '@/lib/api';
import { useApp } from '@/context/AppContext';

export function usePharmacies() {
  const { addNotification } = useApp();
  const [pharmacies, setPharmacies]     = useState([]);
  const [loading, setLoading]           = useState(false);
  const [error, setError]               = useState(null);
  const [userPosition, setUserPosition] = useState(null);

  // ── Toutes les pharmacies ────────────────────────────────────
  const fetchAll = useCallback(async () => {
    setLoading(true);
    try {
      const data = await pharmaciesAPI.lister();
      setPharmacies(data.data || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  // ── Pharmacies proches via GPS ───────────────────────────────
  const fetchProches = useCallback(async (rayon = 5000) => {
    if (!navigator.geolocation) {
      setError('Géolocalisation non supportée');
      return;
    }

    setLoading(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        setUserPosition({ latitude, longitude });

        try {
          // Mettre à jour la position du patient côté serveur (PostGIS)
          await patientsAPI.mettreAJourLocalisation(latitude, longitude);

          const data = await pharmaciesAPI.proches(latitude, longitude, rayon);
          setPharmacies(data.data || []);
          addNotification('info', 'Localisation activée', `${data.data?.length || 0} pharmacies trouvées à ${rayon/1000}km`);
        } catch (err) {
          setError(err.message);
        } finally {
          setLoading(false);
        }
      },
      (err) => {
        setError('Impossible de récupérer votre position');
        setLoading(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }, [addNotification]);

  return { pharmacies, loading, error, userPosition, fetchAll, fetchProches };
}
