'use client';
// ordonnance-app/context/AppContext.jsx
// ============================================================
// CONTEXTE GLOBAL — État partagé dans toute l'application
// Wrap ton _app.jsx avec <AppProvider>
// Utilisation : const { user, login, logout } = useApp()
// ============================================================

import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { authAPI } from '@/lib/api';

// ── Création du contexte ─────────────────────────────────────
const AppContext = createContext(null);

// ── Provider principal ───────────────────────────────────────
export function AppProvider({ children }) {
  const [user, setUser]           = useState(null);
  const [token, setToken]         = useState(null);
  const [loading, setLoading]     = useState(true);   // chargement initial
  const [theme, setThemeState]    = useState('light');
  const [lang, setLangState]      = useState('fr');
  const [notifications, setNotifications] = useState([]);
  const [isOnline, setIsOnline]   = useState(true);

  // ── Charger la session au démarrage ─────────────────────────
  useEffect(() => {
    const storedToken = localStorage.getItem('ord_token');
    const storedUser  = localStorage.getItem('ord_user');
    const storedTheme = localStorage.getItem('ord_theme') || 'light';
    const storedLang  = localStorage.getItem('ord_lang')  || 'fr';

    if (storedToken && storedUser) {
      setToken(storedToken);
      setUser(JSON.parse(storedUser));
    }

    setThemeState(storedTheme);
    setLangState(storedLang);
    document.documentElement.setAttribute('data-theme', storedTheme);
    setLoading(false);
  }, []);

  // ── Surveiller la connexion réseau (Offline-First) ──────────
  useEffect(() => {
    const handleOnline  = () => { setIsOnline(true);  addNotification('info', 'Connexion rétablie', 'Synchronisation en cours…'); };
    const handleOffline = () => { setIsOnline(false); addNotification('warn', 'Hors ligne', 'Mode hors ligne activé — données locales utilisées'); };
    window.addEventListener('online',  handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => { window.removeEventListener('online', handleOnline); window.removeEventListener('offline', handleOffline); };
  }, []);

  // ── CONNEXION ────────────────────────────────────────────────
  const login = useCallback(async (email, motDePasse) => {
    const data = await authAPI.connexion(email, motDePasse);

    // Si 2FA requis, retourner l'info sans stocker encore
    if (data.twoFactorRequis) return { twoFactorRequis: true, tokenTemporaire: data.tokenTemporaire };

    // Connexion directe
    storeSession(data.data.token, data.data.utilisateur);
    return { success: true, user: data.data.utilisateur };
  }, []);

  // ── CONNEXION APRÈS 2FA ──────────────────────────────────────
  const loginWith2FA = useCallback(async (tokenTemporaire, code2FA) => {
    const data = await authAPI.verifier2FA(tokenTemporaire, code2FA);
    storeSession(data.data.token, data.data.utilisateur);
    return { success: true, user: data.data.utilisateur };
  }, []);

  // ── DÉCONNEXION ──────────────────────────────────────────────
  const logout = useCallback(() => {
    localStorage.removeItem('ord_token');
    localStorage.removeItem('ord_user');
    setToken(null);
    setUser(null);
  }, []);

  // ── THÈME ────────────────────────────────────────────────────
  const setTheme = useCallback((newTheme) => {
    setThemeState(newTheme);
    localStorage.setItem('ord_theme', newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);
  }, []);

  // ── LANGUE ──────────────────────────────────────────────────
  const setLang = useCallback((newLang) => {
    setLangState(newLang);
    localStorage.setItem('ord_lang', newLang);
  }, []);

  // ── NOTIFICATIONS IN-APP ─────────────────────────────────────
  const addNotification = useCallback((type, title, message) => {
    const notif = { id: Date.now(), type, title, message, read: false, createdAt: new Date() };
    setNotifications(prev => [notif, ...prev.slice(0, 49)]); // max 50
  }, []);

  const markNotificationRead = useCallback((id) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  }, []);

  const clearNotifications = useCallback(() => setNotifications([]), []);

  // ── HELPER INTERNE ───────────────────────────────────────────
  function storeSession(tok, usr) {
    localStorage.setItem('ord_token', tok);
    localStorage.setItem('ord_user', JSON.stringify(usr));
    setToken(tok);
    setUser(usr);
  }

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <AppContext.Provider value={{
      // Auth
      user, token, loading,
      login, loginWith2FA, logout,
      isAuthenticated: !!user,
      // Apparence
      theme, setTheme,
      lang, setLang,
      // Réseau
      isOnline,
      // Notifications
      notifications, unreadCount,
      addNotification, markNotificationRead, clearNotifications,
    }}>
      {children}
    </AppContext.Provider>
  );
}

// ── Hook d'accès ─────────────────────────────────────────────
export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp doit être utilisé dans <AppProvider>');
  return ctx;
}
