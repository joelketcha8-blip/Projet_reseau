'use client';
// ordonnance-app/app/login/page.jsx
// Page de connexion connectée au backend via useAuth

import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';

const ROLES = [
  { id: 'MEDECIN',    label: '🩺 Médecin',    email: 'dr.martin@hopital.cm' },
  { id: 'PATIENT',    label: '🤒 Patient',    email: 'paul.lambert@gmail.com' },
  { id: 'PHARMACIEN', label: '💊 Pharmacien', email: 'pharmacie.centrale@pharm.cm' },
  { id: 'ADMIN',      label: '🔐 Admin',      email: 'admin@ordonnance.cm' },
];

export default function LoginPage() {
  const { loading, error, setError, twoFactorRequired, handleLogin, handle2FA } = useAuth();

  const [email, setEmail]         = useState('dr.martin@hopital.cm');
  const [password, setPassword]   = useState('');
  const [code2FA, setCode2FA]     = useState('');
  const [roleActif, setRoleActif] = useState('MEDECIN');

  function pickRole(role) {
    setRoleActif(role.id);
    setEmail(role.email);
    setError(null);
  }

  async function onSubmit(e) {
    e.preventDefault();
    if (twoFactorRequired) {
      await handle2FA(code2FA);
    } else {
      await handleLogin(email, password);
    }
  }

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 16, padding: 36, width: 400, boxShadow: 'var(--shadow-md)' }}>

        {/* Logo */}
        <div style={{ width: 52, height: 52, background: 'var(--primary)', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
          <svg viewBox="0 0 24 24" fill="white" width={28} height={28}><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 3c1.93 0 3.5 1.57 3.5 3.5S13.93 13 12 13s-3.5-1.57-3.5-3.5S10.07 6 12 6zm7 13H5v-.23c0-.62.28-1.2.76-1.58C7.47 15.82 9.64 15 12 15s4.53.82 6.24 2.19c.48.38.76.97.76 1.58V19z"/></svg>
        </div>

        <h1 style={{ fontFamily: 'Crimson Pro, serif', fontSize: 26, textAlign: 'center', color: 'var(--text)', marginBottom: 4 }}>Ordonnance</h1>
        <p style={{ fontSize: 12, color: 'var(--text3)', textAlign: 'center', marginBottom: 22 }}>Plateforme médicale numérique sécurisée</p>

        {/* Sélecteur de rôle */}
        {!twoFactorRequired && (
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'center', marginBottom: 20 }}>
            {ROLES.map(r => (
              <button key={r.id}
                onClick={() => pickRole(r)}
                style={{
                  padding: '6px 14px', borderRadius: 20, border: '1px solid var(--border)',
                  background: roleActif === r.id ? 'var(--primary)' : 'var(--surface)',
                  color: roleActif === r.id ? 'white' : 'var(--text2)',
                  fontWeight: roleActif === r.id ? 600 : 400,
                  fontSize: 12, cursor: 'pointer', fontFamily: 'Inter, sans-serif'
                }}>
                {r.label}
              </button>
            ))}
          </div>
        )}

        {/* Message d'erreur */}
        {error && (
          <div style={{ background: 'var(--danger-bg)', border: '1px solid rgba(229,57,53,.2)', borderRadius: 8, padding: '10px 14px', marginBottom: 14, fontSize: 13, color: 'var(--danger)' }}>
            ⚠️ {error}
          </div>
        )}

        <form onSubmit={onSubmit}>
          {twoFactorRequired ? (
            /* Étape 2FA */
            <>
              <div style={{ textAlign: 'center', marginBottom: 16 }}>
                <div style={{ fontSize: 32, marginBottom: 8 }}>🔐</div>
                <p style={{ fontSize: 14, color: 'var(--text)', fontWeight: 500 }}>Vérification en deux étapes</p>
                <p style={{ fontSize: 12, color: 'var(--text3)' }}>Entrez le code de votre application d'authentification</p>
              </div>
              <div style={{ marginBottom: 20 }}>
                <label style={{ fontSize: 12, fontWeight: 500, color: 'var(--text2)', display: 'block', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '.5px' }}>Code à 6 chiffres</label>
                <input
                  value={code2FA}
                  onChange={e => setCode2FA(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  placeholder="000000"
                  maxLength={6}
                  style={{ width: '100%', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 8, padding: '12px', color: 'var(--text)', fontSize: 24, fontFamily: 'Crimson Pro, serif', letterSpacing: 8, textAlign: 'center', outline: 'none' }}
                  autoFocus
                />
              </div>
            </>
          ) : (
            /* Étape Email/Mot de passe */
            <>
              <div style={{ marginBottom: 14 }}>
                <label style={{ fontSize: 12, fontWeight: 500, color: 'var(--text2)', display: 'block', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '.5px' }}>Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  style={{ width: '100%', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 8, padding: '9px 12px', color: 'var(--text)', fontSize: 13, outline: 'none', fontFamily: 'Inter, sans-serif' }}
                  required
                />
              </div>
              <div style={{ marginBottom: 20 }}>
                <label style={{ fontSize: 12, fontWeight: 500, color: 'var(--text2)', display: 'block', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '.5px' }}>Mot de passe</label>
                <input
                  type="password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  style={{ width: '100%', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 8, padding: '9px 12px', color: 'var(--text)', fontSize: 13, outline: 'none', fontFamily: 'Inter, sans-serif' }}
                  required
                />
              </div>
            </>
          )}

          <button
            type="submit"
            disabled={loading}
            style={{ width: '100%', background: loading ? 'var(--text3)' : 'var(--primary)', border: 'none', borderRadius: 8, padding: 11, color: 'white', fontSize: 14, fontWeight: 500, cursor: loading ? 'not-allowed' : 'pointer', fontFamily: 'Inter, sans-serif', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
            {loading ? (
              <>
                <svg style={{ animation: 'spin 1s linear infinite' }} viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth={2} width={16} height={16}>
                  <circle cx={12} cy={12} r={10} strokeOpacity={.3}/>
                  <path d="M12 2a10 10 0 0 1 10 10" />
                </svg>
                Connexion en cours…
              </>
            ) : twoFactorRequired ? 'Vérifier le code' : 'Se connecter'}
          </button>
        </form>

        <p style={{ textAlign: 'center', fontSize: 11, color: 'var(--text3)', marginTop: 14 }}>
          OAuth2 · JWT · 2FA · Sécurisé · Multi-tenant
        </p>
      </div>
      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
