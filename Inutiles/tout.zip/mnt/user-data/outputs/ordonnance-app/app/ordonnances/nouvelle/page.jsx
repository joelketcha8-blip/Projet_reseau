'use client';
// ordonnance-app/app/ordonnances/nouvelle/page.jsx

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useOrdonnances } from '@/hooks/useOrdonnances';
import { useMedicaments } from '@/hooks/useMedicaments';

const PATIENTS_MOCK = [
  { id: 'pat-001', nom: 'Bernard', prenom: 'Sophie' },
  { id: 'pat-002', nom: 'Lambert', prenom: 'Paul' },
  { id: 'pat-003', nom: 'Curie', prenom: 'Marie' },
  { id: 'pat-004', nom: 'Dupont', prenom: 'Jean' },
];

function LigneMedicament({ ligne, index, medicaments, onChange, onRemove }) {
  return (
    <div style={{ background: 'var(--surface2)', border: '1px solid var(--border)', borderRadius: 8, padding: 12, marginBottom: 10, position: 'relative' }}>
      {index > 0 && (
        <button onClick={() => onRemove(index)} style={{ position: 'absolute', top: 8, right: 8, background: 'var(--danger-bg)', border: 'none', borderRadius: 6, padding: '2px 8px', cursor: 'pointer', fontSize: 12, color: 'var(--danger)' }}>✕ Retirer</button>
      )}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
        <div>
          <label style={{ fontSize: 12, fontWeight: 500, color: 'var(--text2)', display: 'block', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '.4px' }}>Médicament</label>
          <select
            value={ligne.medicamentId}
            onChange={e => onChange(index, 'medicamentId', e.target.value)}
            style={{ width: '100%', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 8, padding: '9px 12px', color: 'var(--text)', fontSize: 13, fontFamily: 'Inter, sans-serif', outline: 'none' }}>
            <option value="">-- Sélectionner --</option>
            {medicaments.map(m => <option key={m.id} value={m.id}>{m.nom} {m.dosageStandard}</option>)}
          </select>
        </div>
        <div>
          <label style={{ fontSize: 12, fontWeight: 500, color: 'var(--text2)', display: 'block', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '.4px' }}>Dosage</label>
          <input value={ligne.dosage} onChange={e => onChange(index, 'dosage', e.target.value)} placeholder="500mg" style={{ width: '100%', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 8, padding: '9px 12px', color: 'var(--text)', fontSize: 13, outline: 'none' }} />
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, marginBottom: 10 }}>
        <div>
          <label style={{ fontSize: 12, fontWeight: 500, color: 'var(--text2)', display: 'block', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '.4px' }}>Fréquence</label>
          <select value={ligne.frequence} onChange={e => onChange(index, 'frequence', e.target.value)} style={{ width: '100%', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 8, padding: '9px 12px', color: 'var(--text)', fontSize: 13, fontFamily: 'Inter, sans-serif', outline: 'none' }}>
            <option>3 fois par jour</option>
            <option>2 fois par jour</option>
            <option>1 fois par jour</option>
            <option>Matin et soir</option>
          </select>
        </div>
        <div>
          <label style={{ fontSize: 12, fontWeight: 500, color: 'var(--text2)', display: 'block', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '.4px' }}>Durée</label>
          <input value={ligne.duree} onChange={e => onChange(index, 'duree', e.target.value)} placeholder="7 jours" style={{ width: '100%', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 8, padding: '9px 12px', color: 'var(--text)', fontSize: 13, outline: 'none' }} />
        </div>
        <div>
          <label style={{ fontSize: 12, fontWeight: 500, color: 'var(--text2)', display: 'block', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '.4px' }}>Quantité</label>
          <input type="number" min={1} value={ligne.quantitePrescrite} onChange={e => onChange(index, 'quantitePrescrite', parseInt(e.target.value))} style={{ width: '100%', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 8, padding: '9px 12px', color: 'var(--text)', fontSize: 13, outline: 'none' }} />
        </div>
      </div>
      <div>
        <label style={{ fontSize: 12, fontWeight: 500, color: 'var(--text2)', display: 'block', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '.4px' }}>Instructions (optionnel)</label>
        <input value={ligne.instructions} onChange={e => onChange(index, 'instructions', e.target.value)} placeholder="Ex: Prendre pendant les repas" style={{ width: '100%', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 8, padding: '9px 12px', color: 'var(--text)', fontSize: 13, outline: 'none' }} />
      </div>
    </div>
  );
}

const lignePar_default = () => ({ medicamentId: '', dosage: '', frequence: '3 fois par jour', duree: '7 jours', quantitePrescrite: 14, instructions: '' });

export default function NouvelleOrdonnancePage() {
  const router = useRouter();
  const { creerOrdonnance, loading } = useOrdonnances();
  const { medicaments } = useMedicaments();
  const [patientId, setPatientId]   = useState('');
  const [notes, setNotes]           = useState('');
  const [lignes, setLignes]         = useState([lignePar_default()]);
  const [error, setError]           = useState(null);
  const [success, setSuccess]       = useState(null);

  function updateLigne(idx, field, value) {
    setLignes(prev => prev.map((l, i) => i === idx ? { ...l, [field]: value } : l));
  }
  function removeLigne(idx) { setLignes(prev => prev.filter((_, i) => i !== idx)); }
  function addLigne()       { setLignes(prev => [...prev, lignePar_default()]); }

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    if (!patientId) { setError('Veuillez sélectionner un patient.'); return; }
    if (lignes.some(l => !l.medicamentId)) { setError('Veuillez sélectionner un médicament pour chaque ligne.'); return; }

    const result = await creerOrdonnance({
      patientId,
      notesMedecin: notes,
      medicaments: lignes,
    });

    if (result.success) {
      setSuccess(result.ordonnance.code);
    } else {
      setError(result.error);
    }
  }

  // Confirmation de succès
  if (success) {
    return (
      <div style={{ maxWidth: 480, margin: '60px auto', textAlign: 'center' }}>
        <div style={{ width: 72, height: 72, background: 'var(--primary-light)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px', border: '2px solid var(--primary)' }}>
          <svg viewBox="0 0 24 24" fill="var(--primary)" width={32} height={32}><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
        </div>
        <h2 style={{ fontFamily: 'Crimson Pro, serif', fontSize: 26, color: 'var(--text)', marginBottom: 8 }}>Ordonnance créée !</h2>
        <p style={{ fontFamily: 'Crimson Pro, serif', fontSize: 20, color: 'var(--primary)', marginBottom: 6 }}>{success}</p>
        <p style={{ fontSize: 13, color: 'var(--text3)', marginBottom: 24 }}>Le patient a été notifié. QR Code généré.</p>
        <div style={{ display: 'flex', gap: 10, justifyContent: 'center' }}>
          <button className="btn btn-primary" onClick={() => router.push(`/ordonnances/${success}`)}>Voir l'ordonnance</button>
          <button className="btn btn-secondary" onClick={() => { setSuccess(null); setLignes([lignePar_default()]); setPatientId(''); setNotes(''); }}>Créer une autre</button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 680 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 22 }}>
        <button className="btn btn-ghost btn-sm btn-icon" onClick={() => router.back()}>
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg>
        </button>
        <h2 style={{ fontFamily: 'Crimson Pro, serif', fontSize: 22, color: 'var(--text)' }}>Nouvelle ordonnance</h2>
      </div>

      {error && (
        <div style={{ background: 'var(--danger-bg)', border: '1px solid rgba(229,57,53,.2)', borderRadius: 8, padding: '10px 14px', marginBottom: 16, fontSize: 13, color: 'var(--danger)' }}>
          ⚠️ {error}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="card">
          <div className="card-title">Informations du patient</div>
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 12, fontWeight: 500, color: 'var(--text2)', display: 'block', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '.4px' }}>Patient *</label>
            <select value={patientId} onChange={e => setPatientId(e.target.value)} required
              style={{ width: '100%', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 8, padding: '9px 12px', color: 'var(--text)', fontSize: 13, fontFamily: 'Inter, sans-serif', outline: 'none' }}>
              <option value="">-- Sélectionner un patient --</option>
              {PATIENTS_MOCK.map(p => <option key={p.id} value={p.id}>{p.prenom} {p.nom}</option>)}
            </select>
          </div>
          <div>
            <label style={{ fontSize: 12, fontWeight: 500, color: 'var(--text2)', display: 'block', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '.4px' }}>Notes générales (optionnel)</label>
            <textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder="Instructions générales, contre-indications…"
              style={{ width: '100%', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 8, padding: '9px 12px', color: 'var(--text)', fontSize: 13, fontFamily: 'Inter, sans-serif', outline: 'none', minHeight: 72, resize: 'vertical' }} />
          </div>
        </div>

        <div className="card">
          <div className="card-title">Médicaments prescrits</div>
          {lignes.map((l, i) => (
            <LigneMedicament key={i} ligne={l} index={i} medicaments={medicaments} onChange={updateLigne} onRemove={removeLigne} />
          ))}
          <button type="button" onClick={addLigne}
            style={{ width: '100%', background: 'transparent', border: '1px dashed var(--border)', borderRadius: 8, padding: 10, color: 'var(--text3)', cursor: 'pointer', fontSize: 13, fontFamily: 'Inter, sans-serif', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
            + Ajouter un médicament
          </button>
        </div>

        <div style={{ background: 'var(--primary-light)', border: '1px solid rgba(37,162,68,.2)', borderRadius: 8, padding: 12, marginBottom: 16, fontSize: 12, color: 'var(--primary-dark)' }}>
          ✍️ Signature numérique activée — Ordonnance sécurisée par OAuth2 + JWT
        </div>

        <div style={{ display: 'flex', gap: 10 }}>
          <button type="button" className="btn btn-secondary" onClick={() => router.back()}>Annuler</button>
          <button type="submit" className="btn btn-primary" disabled={loading} style={{ flex: 1, justifyContent: 'center' }}>
            {loading ? 'Création en cours…' : 'Créer l\'ordonnance'}
          </button>
        </div>
      </form>
    </div>
  );
}
