'use client';
// ordonnance-app/app/dashboard/page.jsx
// Dashboard dynamique connecté à l'API

import { useApp } from '@/context/AppContext';
import { useOrdonnances } from '@/hooks/useOrdonnances';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

// Badge de statut réutilisable
function StatusBadge({ statut }) {
  const map = {
    ACTIVE:               { label: 'Active',    cls: 'badge-green' },
    PARTIELLEMENT_UTILISEE:{ label: 'Partielle', cls: 'badge-yellow' },
    TERMINEE:             { label: 'Terminée',  cls: 'badge-blue' },
    EXPIREE:              { label: 'Expirée',   cls: 'badge-red' },
    ANNULEE:              { label: 'Annulée',   cls: 'badge-gray' },
  };
  const s = map[statut] || { label: statut, cls: 'badge-gray' };
  return <span className={`badge ${s.cls}`}>{s.label}</span>;
}

// Carte de statistique
function StatCard({ value, label, delta, deltaColor }) {
  return (
    <div className="stat-box">
      <div className="stat-num">{value}</div>
      <div className="stat-label">{label}</div>
      {delta && <div className="stat-delta" style={deltaColor ? { color: deltaColor } : {}}>{delta}</div>}
    </div>
  );
}

export default function DashboardPage() {
  const { user, isAuthenticated } = useApp();
  const router = useRouter();
  const { ordonnances, loading, error, creerOrdonnance } = useOrdonnances({ page: 1, limite: 5 });

  // Rediriger si non connecté
  useEffect(() => {
    if (!isAuthenticated) router.push('/login');
  }, [isAuthenticated]);

  if (!user) return null;

  const actives    = ordonnances.filter(o => o.statut === 'ACTIVE').length;
  const partielles = ordonnances.filter(o => o.statut === 'PARTIELLEMENT_UTILISEE').length;

  return (
    <div>
      {/* En-tête */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 }}>
        <div>
          <h2 style={{ fontFamily: 'Crimson Pro, serif', fontSize: 22, color: 'var(--text)' }}>
            Bonjour, {user.role === 'MEDECIN' ? 'Dr. ' : ''}{user.prenom} 👋
          </h2>
          <p style={{ fontSize: 12, color: 'var(--text3)', marginTop: 3 }}>
            <span className="live-dot" /> Temps réel actif · Apache Kafka
          </p>
        </div>
        {user.role === 'MEDECIN' && (
          <button className="btn btn-primary" onClick={() => router.push('/ordonnances/nouvelle')}>
            <svg viewBox="0 0 24 24" fill="currentColor" style={{ width: 15, height: 15 }}><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
            Nouvelle ordonnance
          </button>
        )}
        {user.role === 'PHARMACIEN' && (
          <button className="btn btn-primary" onClick={() => router.push('/scanner')}>
            Scanner une ordonnance
          </button>
        )}
      </div>

      {/* Stats */}
      <div className="stats-grid">
        <StatCard value={ordonnances.length} label="Ordonnances" delta="Ce mois" />
        <StatCard value={actives} label="Actives" delta="↑ En cours" />
        <StatCard value={partielles} label="Partielles" deltaColor="var(--warn)" delta="→ À compléter" />
        <StatCard value="97%" label="Taux validation" delta="↑ Excellent" />
      </div>

      {/* Erreur API */}
      {error && (
        <div style={{ background: 'var(--danger-bg)', border: '1px solid rgba(229,57,53,.2)', borderRadius: 8, padding: '12px 16px', marginBottom: 14, fontSize: 13, color: 'var(--danger)' }}>
          ⚠️ Impossible de charger les ordonnances : {error}
          <br/><span style={{ fontSize: 11, opacity: .7 }}>Vérifiez que le mock-backend tourne sur le port 3001.</span>
        </div>
      )}

      {/* Liste ordonnances */}
      <div className="card">
        <div className="card-header">
          <div>
            <div className="card-title">Ordonnances récentes</div>
            <div className="card-sub">{actives} active{actives > 1 ? 's' : ''}</div>
          </div>
          <button className="btn btn-ghost btn-sm" onClick={() => router.push('/ordonnances')}>Tout voir →</button>
        </div>

        {loading ? (
          <div style={{ textAlign: 'center', padding: '24px', color: 'var(--text3)' }}>
            <div style={{ fontSize: 13 }}>Chargement…</div>
          </div>
        ) : ordonnances.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '24px', color: 'var(--text3)', fontSize: 13 }}>
            Aucune ordonnance pour le moment.
          </div>
        ) : (
          ordonnances.map(ord => (
            <div key={ord.id} className="ord-item" onClick={() => router.push(`/ordonnances/${ord.code}`)}>
              <div style={{ flex: 1 }}>
                <div className="ord-code">{ord.code}</div>
                <div className="ord-patient">
                  {ord.patient?.prenom} {ord.patient?.nom} · {new Date(ord.dateCreation).toLocaleDateString('fr-FR')}
                </div>
                <div className="progress-bar">
                  <div className="progress-fill" style={{
                    width: ord.statut === 'TERMINEE' ? '100%' :
                           ord.statut === 'PARTIELLEMENT_UTILISEE' ? '50%' : '0%'
                  }} />
                </div>
              </div>
              <StatusBadge statut={ord.statut} />
            </div>
          ))
        )}
      </div>
    </div>
  );
}
