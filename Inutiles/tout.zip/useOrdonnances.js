'use client';
// ordonnance-app/hooks/useOrdonnances.js
// Hook pour gérer les ordonnances : liste, création, délivrance

import { useState, useEffect, useCallback } from 'react';
import { ordonnancesAPI } from '@/lib/api';
import { useApp } from '@/context/AppContext';

export function useOrdonnances(params = {}) {
  const { addNotification, isOnline } = useApp();
  const [ordonnances, setOrdonnances] = useState([]);
  const [loading, setLoading]         = useState(false);
  const [error, setError]             = useState(null);
  const [pagination, setPagination]   = useState(null);

  // ── Charger les ordonnances ──────────────────────────────────
  const fetchOrdonnances = useCallback(async () => {
    // Mode hors ligne : utiliser le cache local
    if (!isOnline) {
      const cached = localStorage.getItem('ord_cache_ordonnances');
      if (cached) { setOrdonnances(JSON.parse(cached)); return; }
    }

    setLoading(true);
    setError(null);
    try {
      const data = await ordonnancesAPI.lister(params);
      setOrdonnances(data.data || []);
      setPagination(data.pagination || null);
      // Mettre en cache pour le mode hors ligne
      localStorage.setItem('ord_cache_ordonnances', JSON.stringify(data.data || []));
    } catch (err) {
      setError(err.message);
      // Essayer le cache en cas d'erreur réseau
      const cached = localStorage.getItem('ord_cache_ordonnances');
      if (cached) setOrdonnances(JSON.parse(cached));
    } finally {
      setLoading(false);
    }
  }, [isOnline, JSON.stringify(params)]);

  useEffect(() => { fetchOrdonnances(); }, [fetchOrdonnances]);

  // ── Créer une ordonnance ─────────────────────────────────────
  const creerOrdonnance = useCallback(async (payload) => {
    setLoading(true);
    try {
      const data = await ordonnancesAPI.creer(payload);
      const nouvelleOrd = data.data;
      setOrdonnances(prev => [nouvelleOrd, ...prev]);
      addNotification('success', 'Ordonnance créée', `${nouvelleOrd.code} — Patient notifié`);
      return { success: true, ordonnance: nouvelleOrd };
    } catch (err) {
      addNotification('error', 'Erreur', err.message);
      return { success: false, error: err.message };
    } finally {
      setLoading(false);
    }
  }, [addNotification]);

  // ── Annuler une ordonnance ───────────────────────────────────
  const annulerOrdonnance = useCallback(async (code) => {
    try {
      await ordonnancesAPI.annuler(code);
      setOrdonnances(prev =>
        prev.map(o => o.code === code ? { ...o, statut: 'ANNULEE' } : o)
      );
      addNotification('info', 'Ordonnance annulée', code);
      return { success: true };
    } catch (err) {
      addNotification('error', 'Erreur', err.message);
      return { success: false, error: err.message };
    }
  }, [addNotification]);

  // ── Délivrer des médicaments ─────────────────────────────────
  const delivrerOrdonnance = useCallback(async (code, payload) => {
    setLoading(true);
    try {
      const data = await ordonnancesAPI.delivrer(code, payload);
      const ordMaj = data.data;
      setOrdonnances(prev =>
        prev.map(o => o.code === code ? ordMaj : o)
      );
      addNotification('success', 'Délivrance enregistrée', `${code} — Médecin notifié`);
      return { success: true, ordonnance: ordMaj };
    } catch (err) {
      addNotification('error', 'Erreur délivrance', err.message);
      return { success: false, error: err.message };
    } finally {
      setLoading(false);
    }
  }, [addNotification]);

  return {
    ordonnances, loading, error, pagination,
    fetchOrdonnances,
    creerOrdonnance,
    annulerOrdonnance,
    delivrerOrdonnance,
  };
}

// ── Hook pour une ordonnance unique ─────────────────────────
export function useOrdonnance(code) {
  const [ordonnance, setOrdonnance] = useState(null);
  const [loading, setLoading]       = useState(false);
  const [error, setError]           = useState(null);

  useEffect(() => {
    if (!code) return;
    setLoading(true);
    ordonnancesAPI.getByCode(code)
      .then(data => setOrdonnance(data.data))
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, [code]);

  return { ordonnance, loading, error };
}
