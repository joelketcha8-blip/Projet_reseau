// ordonnance-app/lib/api.js
// ============================================================
// CLIENT API CENTRALISÉ
// Toutes les requêtes vers le mock-backend passent par ici.
// Utilisation : import api from '@/lib/api'
// ============================================================

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api';

// ── Récupère le token JWT stocké dans localStorage ──────────
function getToken() {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('ord_token');
}

// ── Construit les headers avec le token si disponible ───────
function buildHeaders(extra = {}) {
  const headers = { 'Content-Type': 'application/json', ...extra };
  const token = getToken();
  if (token) headers['Authorization'] = `Bearer ${token}`;
  return headers;
}

// ── Fonction fetch centrale avec gestion d'erreurs ──────────
async function request(method, path, body = null) {
  const options = {
    method,
    headers: buildHeaders(),
  };
  if (body) options.body = JSON.stringify(body);

  const response = await fetch(`${BASE_URL}${path}`, options);
  const data = await response.json();

  // Si le serveur retourne 401, le token a expiré → déconnecter
  if (response.status === 401) {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('ord_token');
      localStorage.removeItem('ord_user');
      window.location.href = '/login';
    }
    throw new Error(data.message || 'Session expirée');
  }

  if (!response.ok) {
    throw new Error(data.message || `Erreur ${response.status}`);
  }

  return data;
}

// ============================================================
// AUTH
// ============================================================
export const authAPI = {
  /** Créer un compte */
  inscription: (payload) => request('POST', '/auth/inscription', payload),

  /** Se connecter → retourne { token, tokenRefresh, utilisateur } */
  connexion: (email, motDePasse) =>
    request('POST', '/auth/connexion', { email, motDePasse }),

  /** Vérifier le code 2FA */
  verifier2FA: (tokenTemporaire, code2FA) =>
    request('POST', '/auth/verifier-2fa', { tokenTemporaire, code2FA }),

  /** Activer la 2FA → retourne le QR code */
  activer2FA: () => request('POST', '/auth/activer-2fa'),

  /** Confirmer l'activation 2FA avec le code */
  confirmer2FA: (code) => request('POST', '/auth/confirmer-2fa', { code }),

  /** Mon profil */
  moi: () => request('GET', '/auth/moi'),
};

// ============================================================
// ORDONNANCES
// ============================================================
export const ordonnancesAPI = {
  /** Mes ordonnances (médecin = créées, patient = reçues) */
  lister: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request('GET', `/ordonnances${q ? '?' + q : ''}`);
  },

  /** Voir une ordonnance par code ORD-XXXX-XXXXX ou UUID */
  getByCode: (code) => request('GET', `/ordonnances/${code}`),

  /** Créer une ordonnance (médecin seulement) */
  creer: (payload) => request('POST', '/ordonnances', payload),

  /** Annuler une ordonnance (médecin seulement) */
  annuler: (code) => request('DELETE', `/ordonnances/${code}`),

  /** Délivrer des médicaments (pharmacien seulement) */
  delivrer: (code, payload) =>
    request('POST', `/ordonnances/${code}/delivrer`, payload),
};

// ============================================================
// MÉDICAMENTS
// ============================================================
export const medicamentsAPI = {
  /** Lister les médicaments avec recherche et pagination */
  lister: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request('GET', `/medicaments${q ? '?' + q : ''}`);
  },

  /** Détail d'un médicament */
  get: (id) => request('GET', `/medicaments/${id}`),

  /** Ajouter un médicament (admin/médecin) */
  ajouter: (payload) => request('POST', '/medicaments', payload),
};

// ============================================================
// PATIENTS
// ============================================================
export const patientsAPI = {
  /** Mes patients (médecin) */
  mesPatients: (recherche = '') =>
    request('GET', `/patients${recherche ? '?recherche=' + recherche : ''}`),

  /** Mon profil patient */
  monProfil: () => request('GET', '/patients/moi'),

  /** Mettre à jour ma localisation GPS */
  mettreAJourLocalisation: (latitude, longitude) =>
    request('PUT', '/patients/localisation', { latitude, longitude }),
};

// ============================================================
// PHARMACIES
// ============================================================
export const pharmaciesAPI = {
  /** Toutes les pharmacies */
  lister: () => request('GET', '/pharmacies'),

  /** Pharmacies proches (GPS) */
  proches: (lat, lng, rayon = 5000) =>
    request('GET', `/pharmacies/proches?lat=${lat}&lng=${lng}&rayon=${rayon}`),
};

// ============================================================
// SANTÉ DE L'API
// ============================================================
export const healthAPI = {
  check: () => request('GET', '/health'),
};

// ── Export par défaut : tout regroupé ───────────────────────
const api = { auth: authAPI, ordonnances: ordonnancesAPI, medicaments: medicamentsAPI, patients: patientsAPI, pharmacies: pharmaciesAPI, health: healthAPI };
export default api;
